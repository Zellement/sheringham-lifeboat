<!---<li><a class="fb" onclick="window.open(this.href); return false" href="https://www.facebook.com/pages/Sheringham-Lifeboat-Station/478842185489622?ref=ts&fref=ts">Like us on Facebook</a></li>
<li><a class="tw" onclick="window.open(this.href); return false" href="#">Follow us on Twitter</a></li>
<li><a class="g" onclick="window.open(this.href); return false" href="https://plus.google.com/108618014306968005071">Find us on Google+</a></li>
-->