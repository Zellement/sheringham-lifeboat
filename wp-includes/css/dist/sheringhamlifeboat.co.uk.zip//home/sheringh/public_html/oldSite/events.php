<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Sheringham Lifeboat Events";
		include("site_specific/defines.php");

	?>

<title>Events - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="Upcoming events from Sheringham Lifeboat Station" />
	<meta name="keywords" content="sheringham lifeboat station, station, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">Events</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

			<p>All upcoming public events can be found here.</p>

			<hr />

			<div class="unifyRepeatArea">
<div class="single-event unifyRepeat"><div class="single-event-left"><p class="single-event-title">Date</p><p class="single-event-detail">Sunday&nbsp; 16th August 2015</p><p class="single-event-title">Time</p><p class="single-event-detail">10:00 - 16:00</p><p class="single-event-title">Event</p><p class="single-event-detail">Sheringham RNLI Lifeboat day2015</p></div><div class="single-event-details"><p class="single-event-details-header">Details</p><p><strong>Sheringham RNLI - Lifeboat day 2015</strong><strong> <br></strong></p><p>Every year on a Sunday in August two weeks before the late summer bank holiday the Sheringham Lifeboat Station holds what is known as a their Lifeboat Day where the public are invited into the Lifeboat Station to witness the lifeboat being launched as well as meeting crew and shorehelpers and seeing the Lifeboat at close quarters. <br></p><p>The lifeboat station will have many items on display and there are stalls with items for sale and teas to be had, games to be palyed and fun for all.</p><p>The day starts with a demonstation by the local Coastguard Unit of how to abseil down the local cliffs to demonstrate another part of their wide reaching search and rescue skills. &nbsp; </p><p>At this point we often do&nbsp; the first launch of the lifeboat where a casualty will be rescued from a remote cliff by the coastguard and taken to safety where their injuries can be properly treated. <br></p><p>RNLI Lifeguards are encouraged to demonstrate their lifesaving skills on their boards and their knowledge of the inshore waters and in most years we are visited by our colleagues from Cromer who send over their two Lifeboats to train with our Atlantic 85.</p><p>All in all we have a very busy and rewarding day enjoyed by all.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p>Normally from 1pm to 2 pm we are entertained by the Sheringham Shantymen who&nbsp; are great supporters of the RNLI and give their time and energy freely.<br></p><p>At 3 pm to 4 pm we hold the annual multi denomination Lifeboat Service supported by the Salvation Army Band which has become an important event in our local calendar.</p><p>Finally many of us go over the the Carnser car park at Blakeney for 4.30 pm where they hold their Annual Lifeboat Service for the Sheringham Lifeboat. If the tides times are right the Lifeboat goes along to the Quay as well.</p><p>All in all a very busy and rewarding day.<br></p><p><em>Brian J Farrow</em></p><p><em>Lifeboat Operations Manager</em></p><p><em>Sheringham RNLI</em></p></div></div><div class="single-event unifyRepeat"><div class="single-event-left"><p class="single-event-title">Date</p><p class="single-event-detail">Saturday 18th July 2015</p><p class="single-event-title">Time</p><p class="single-event-detail">09:00 - 15:00</p><p class="single-event-title">Event</p><p class="single-event-detail">Sheringham RNLI Flag Day 2015</p></div><div class="single-event-details"><p class="single-event-details-header">Details</p><p><br></p><p><strong>Sheringham RNLI - Flag day 2015</strong><strong> <br></strong></p><p>Every year on or about the third Saturday in July the Sheringham Station hold what is known as a licenced Flag day where supporters of the RNLI will be on the streets selling their Flags. </p><p>It is the one day in the year where supporters of the local RNLI sell small stick-on Flags to the public in order to raise money to continue to undertake the principle for which the RNLI was orginally founded in 1824 by Sir William Hillary;&nbsp; <em>The saving of Life at Sea.</em><br></p><p>Although the sums of money raised are not enormous they do demonstrate to the wider public the committtment of local people to maintaining the lifeboat service and the principle of saving life at sea.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br></p><p><br></p><p><em>Brian J Farrow</em></p><p><em>Lifeboat Operations Manager</em></p><p><em>Sheringham RNLI</em></p></div></div><div class="single-event unifyRepeat"><div class="single-event-left"><p class="single-event-title">Date</p><p class="single-event-detail">Sunday 10th August 2014</p><p class="single-event-title">Time</p><p class="single-event-detail">10:00 - 16:00</p><p class="single-event-title">Event</p><p class="single-event-detail">Lifeboat Day 2014</p></div><div class="single-event-details"><p class="single-event-details-header">Details</p><p>The following is a copy of a letter published in the local press following Lifeboat Day 2014.</p><p><strong>Sheringham RNLI - Lifeboat Day 2014</strong><strong>&nbsp;</strong></p>
<p>May I through your pages send a sincere message of thanks to all of the individuals and associations who made our Lifeboat Day 2014 so very special?&nbsp;</p>
<p>To the coastguards who demonstrated their climbing and cliff rescue skills and the RNLI Lifeguards who rescued an itinerant swimmer in distress amongst the crab pot buoys. To the Air Sea Rescue team from Wattisham flying their Sea King Helicopter transferring and lifting crew from lifeboat to lifeboat at various times in horrendous conditions with variable visibility and the occasional rain squall; and with three Lifeboats, including two from Cromer, weaving their way through squally seas, it was a sight to behold.</p>
<p>&nbsp;The public were further entertained by the RNLI shop personnel running a tombola and supplying refreshments at modest prices and gifts on sale from the Mo Museum.&nbsp; After the sea borne displays the Sheringham Shantymen gave their usual polished performance inside the lifeboat station to rapturous applause from a keen audience of locals and holiday makers.&nbsp; Whilst all of this was going on the Norwich Model Boat club were using the Leas boating pond to sail their models and demonstrate the quality of their modelling skills.</p>
<p>The day finished with The Rev C Heycocks coordinating the annual lifeboat service with local churches and the Salvation Army band to a packed congregation inside the Lifeboat station.</p>
<p>&nbsp;Lastly, to all those steadfast souls who have pushed and pulled behind the scenes to make this annual event continue to be worthwhile, I thank you all.</p>
<p>&nbsp;</p>
<p><em>Brian J Farrow</em></p>
<p><em>Lifeboat Operations Manager</em></p>
<p><em>Sheringham RNLI</em></p></div></div>
</div>

		</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>