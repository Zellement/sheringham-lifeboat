<li><a class="index-a" href="index">Home</a></li>
<li><a class="station-a" href="station">Station</a></li>
<li><a class="lifeboat-a" href="lifeboat">Lifeboat</a></li>
<li><a class="crew-a" href="crew">Crew</a></li>
<li><a class="tractor-a" href="tractor">Tractor</a></li>
<li><a class="shouts-a" href="shouts">Shouts</a></li>
<li><a class="history-a" href="history">History</a></li>
<li><a class="events-a" href="events">Events</a></li>
<?php if ($detect->isiOS() ) : ?>
<li><a class="gallery-a" href="fb://profile/478842185489622">Gallery</a></li>
<?php else : ?>
<li><a class="gallery-a" onclick="window.open(this.href); return false" href="https://www.facebook.com/sheringhamlifeboat/photos_albums">Gallery</a></li>
<?php endif; ?>