<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Sheringham Lifeboat Events";
		include("site_specific/defines.php");

	?>

<title>Events - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="Upcoming events from Sheringham Lifeboat Station" />
	<meta name="keywords" content="sheringham lifeboat station, station, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">Events</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

			<p>All upcoming public events can be found here.</p>

			<hr />

			<div class="unifyRepeatArea">
<div class="single-event unifyRepeat"><div class="single-event-left"><p class="single-event-title">Date</p><p class="single-event-detail">Sunday 10th August 2014</p><p class="single-event-title">Time</p><p class="single-event-detail">10:00 - 16:00</p><p class="single-event-title">Event</p><p class="single-event-detail">Lifeboat Day 2014</p></div><div class="single-event-details"><p class="single-event-details-header">Details</p><p>The following is a copy of a letter published in the local press following Lifeboat Day 2014.</p><p><strong>Sheringham RNLI - Lifeboat Day 2014</strong><strong>&nbsp;</strong></p>
<p>May I through your pages send a sincere message of thanks to all of the individuals and associations who made our Lifeboat Day 2014 so very special?&nbsp;</p>
<p>To the coastguards who demonstrated their climbing and cliff rescue skills and the RNLI Lifeguards who rescued an itinerant swimmer in distress amongst the crab pot buoys. To the Air Sea Rescue team from Wattisham flying their Sea King Helicopter transferring and lifting crew from lifeboat to lifeboat at various times in horrendous conditions with variable visibility and the occasional rain squall; and with three Lifeboats, including two from Cromer, weaving their way through squally seas, it was a sight to behold.</p>
<p>&nbsp;The public were further entertained by the RNLI shop personnel running a tombola and supplying refreshments at modest prices and gifts on sale from the Mo Museum.&nbsp; After the sea borne displays the Sheringham Shantymen gave their usual polished performance inside the lifeboat station to rapturous applause from a keen audience of locals and holiday makers.&nbsp; Whilst all of this was going on the Norwich Model Boat club were using the Leas boating pond to sail their models and demonstrate the quality of their modelling skills.</p>
<p>The day finished with The Rev C Heycocks coordinating the annual lifeboat service with local churches and the Salvation Army band to a packed congregation inside the Lifeboat station.</p>
<p>&nbsp;Lastly, to all those steadfast souls who have pushed and pulled behind the scenes to make this annual event continue to be worthwhile, I thank you all.</p>
<p>&nbsp;</p>
<p><em>Brian J Farrow</em></p>
<p><em>Lifeboat Operations Manager</em></p>
<p><em>Sheringham RNLI</em></p></div></div>
</div>

		</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>