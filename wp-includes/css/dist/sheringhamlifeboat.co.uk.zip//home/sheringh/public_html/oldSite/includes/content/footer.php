<footer>

	<div class="container">

		<img src="images/svg/footer-logo.svg" class="logo" alt="Sheringham Lifeboat Logo" />

		<ul class="footersocial">

			<?php include ("includes/content/social.php"); ?>

		</ul>

		<p class="clearfix"><?php echo $address; ?><br />
			T: <?php echo $phonenumber; ?></p>

		<p>&copy; Sheringham Lifeboat, all rights reserved<br />
			The Royal National Lifeboat Institution is a charity registered in England and Wales (209603) and Scotland (SC037736). Charity number CHY 2678 in the Republic of Ireland</p>

		<p><a href="cookies-privacy-policy">Cookies &amp; Privacy Policy</a></p>

		<p>Photography by <a onclick="window.open(this.href); return false" href="http://www.christaylorphoto.co.uk/">Chris Taylor Photography</a><br />
			<a onclick="window.open(this.href); return false" href="http://www.zellement.com">Web Design by Zellement</a><br />
			<a onclick="window.open(this.href); return false" href="http://www.shantymen.com">The Sheringham Shantymen</a></p>

			

	</div>

</footer>