
<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Sheringham Lifeboat Crew";
		include("site_specific/defines.php");

	?>

<title>The Crew - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="All members of the Sheringham crew and the station officers shown on this page are volunteers." />
	<meta name="keywords" content="sheringham lifeboat crew, lifeboat, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">The Crew</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

			<div class="col48">

				<p>Each crew member has a personal set of equipment worth over £500 which he is responsible for maintaining: </p>

				<ul>

					<li><strong>Protective helmet</strong></li>
					<li><strong>Thermal socks</strong> </li>
					<li><strong>Neoprene gloves</strong></li>
					<li><strong>Bear suit</strong> - a thermal body suit worn underneath the dry suit for insulating the body against low temperatures and especially wind chill.</li>
					<li><strong>Drysuit</strong> - with a full immersion proof zip and neck &amp; wrist seals the dry suit keeps the wearer dry inside.</li>
					<li><strong>Lifejacket</strong> - If a crewmember does enter the water this will ensure they float face up even if unconscious. The lifejacket will enable the wearer to remain bouyant even if uninflated but for extra bouyancy it can either be blown up using a mouthpiece or using an integral CO2 cylinder. A double-action handheld flare is in a pocket on either side of the life jacket, at one end of each flare is a day flare which when activated produces a highly visible red smoke. At the other end of each flare is the night flare - a very bright red phosphorous flare which can be seen from great distances at night. The lifejacket also has a torch light which can be attached top of the protective helmet by Velcro in case of going over board at night, and a whistle to assist recovery at night or in foggy conditions.</li>

				</ul>

				<blockquote>All members of the Sheringham crew and the station officers shown below are volunteers.</blockquote>

				<p>If you would like to become part of the crew please contact Brian Farrow (LOM, Lifeboat Operations Manager) or come down to the boathouse on a Wednesday evening from 7:30pm onwards, or Sunday morning from 10am onwards where you will recognise some of these ugly mugs.</p>

			</div>

			<div class="col49">

				<p>Abbreviations shown below:</p>

					<ul>

						<li>LOM = Lifeboat Operations Manager</li>
						<li>Hon Treas = Honorary Treasurer</li>
						<li>HMA = Honorary Medical Advisor</li>
						<li>DLA = Deputy Launching Authority</li>
						<li>Ops Team = Operations Team</li>

					</ul>

				<div class="content-img">
					<img src="images/imgcontent/<?php echo $page; ?>-480.jpg" alt="<?php echo $pagekw; ?>" />
				</div>

			</div>

			<hr />

			<!-- Start Crew Listing -->

			<?php
			    $crewMembers = array(
			        'David Hagan'  => array("Senior Helmsman"),
			        'Paul Wheatland'  => array("Dep Senior Helmsman"),
			        'Chris Taylor'  => array("Helmsman"),
			        'Stephen Banks'  => array("Helmsman"),
			        'Stuart McLeod'  => array("Jnr Helmsman"),
			        'Adam Reith'  => array("Crewman"),
			        'Chris Wright'  => array("Crewman"),
			        'Alice Sizeland'  => array("Crewman"),
			        'Jon Bernard'  => array("Trainee Crewman"),
			        'Liam Cooper'  => array("Trainee Crewman"),
			        'Jamie Crisp'  => array("Trainee Crewman"),
			        'Neil Davies'  => array("Trainee Crewman"),
			        'Paul Harding'  => array("Trainee Crewman"),
			        'Paul Pretty'  => array("Trainee Crewman"),
			        'Andrew Trend'  => array("Trainee Crewman"),
			        'Matthew Price'  => array("Trainee Crewman"),
			        'Kate Webster'  => array("Trainee Crewman")
			    );

			    	foreach ($crewMembers as $crewMember => $otherData) {
				        $crewTitle = $otherData[0];
				        $crewMemberPicture = strtolower(str_replace(" ","-",(str_replace('"',"",$crewMember))));
				?>

				<div class="crew-member">

				    <img src="images/crew/<?php echo $crewMemberPicture; ?>.jpg" alt="<?php echo $crewMember; ?>" />

				    <h4><?php echo $crewMember; ?></h4>
				    <h5><?php echo $crewTitle; ?></h5>

				</div>

				<?php } ?>

				<hr class="clearfix" />

				<?php
				    $crewMembers = array(
				        'Stephen Roberts'  => array("Team Leader/Tractor Driver"),
				        'Mark Herring'  => array("Tractor Driver"),
				        'Stephen Howes'  => array("Tractor Driver"),
				        'Adrian Hubbard'  => array("Tractor Driver"),
				        'Kim Price'  => array("Shorehelper"),
				        'Peter Sharps'  => array("Shorehelper"),
				        'Paul Wadsworth'  => array("Shorehelper"),
				        'Nigel Watts'  => array("Shorehelper")
				    );

				    	foreach ($crewMembers as $crewMember => $otherData) {
					        $crewTitle = $otherData[0];
					        $crewMemberPicture = strtolower(str_replace(" ","-",(str_replace('"',"",$crewMember))));
					?>

					<div class="crew-member">

					    <img src="images/crew/<?php echo $crewMemberPicture; ?>.jpg" alt="<?php echo $crewMember; ?>" />

					    <h4><?php echo $crewMember; ?></h4>
					    <h5><?php echo $crewTitle; ?></h5>

					</div>

					<?php } ?>

				<hr class="clearfix" />

				<?php
				    $crewMembers = array(
				        'Ian Dent'  => array("Head Launcher"),
				        'Bennett Middleton'  => array("Deputy Head Launcher"),
				        'Martyn Jackson'  => array("Training Officer"),
				        'Nick Grice'  => array("Asst Training Co-ordinator"),
				        'Chris Ayers'  => array("Boathouse Manager"),
				        'Trevor Holsey'  => array("DLA/Chair Ops Team"),
				        'David Mann'  => array("DLA/Stn Officer"),
				        'Clive Rayment'  => array("DLA/Training Co-ordinator"),
				        'Brian Farrow'  => array("LOM"),
				        'Dr Peter Sampson'  => array("HMA"),
				        'Phil Hawes'  => array("Chairman"),
				        'Mick Holford'  => array("Hon Treas")
				    );

				    	foreach ($crewMembers as $crewMember => $otherData) {
					        $crewTitle = $otherData[0];
					        $crewMemberPicture = strtolower(str_replace(" ","-",(str_replace('"',"",$crewMember))));
					?>

					<div class="crew-member">

					    <img src="images/crew/<?php echo $crewMemberPicture; ?>.jpg" alt="<?php echo $crewMember; ?>" />

					    <h4><?php echo $crewMember; ?></h4>
					    <h5><?php echo $crewTitle; ?></h5>

					</div>

					<?php } ?>

		</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>