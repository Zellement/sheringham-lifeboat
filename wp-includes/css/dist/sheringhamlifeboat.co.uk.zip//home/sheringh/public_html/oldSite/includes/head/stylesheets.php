<link href="includes/css/master.css" rel="stylesheet" type="text/css" />

<!--[if lte IE 7]>
<link href="includes/css/ie7.css" rel="stylesheet" type="text/css" />
<![endif]-->

<link href="fancybox/jquery.fancybox.css" rel="stylesheet" type="text/css" />

<link rel="shortcut icon" href="favicon.ico" />

<link rel="stylesheet" href="includes/css/dynamic-styling.php?page=<?php echo $page; ?>" type="text/css" />