<?php

// Define The Company Details


$phonenumber		= '01263 823212';

$address			= 'The Promenade, Sheringham, England'

?>
