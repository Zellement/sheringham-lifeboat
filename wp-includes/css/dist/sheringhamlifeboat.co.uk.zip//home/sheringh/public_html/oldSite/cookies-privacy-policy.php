<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = "default";
		$subpage = "default";
		$pagekw = "Sheringham Lifeboat Station";
		include("site_specific/defines.php");

	?>

<title>Cookies &amp; Privacy Policy - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="Page not found. Sorry!" />
	<meta name="keywords" content="sheringham lifeboat station, station, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">Privacy Policy</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

		<?php include ("includes/content/privacy-policy.php"); ?>

		</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>