<?php

	$ftpu = false;
	$ftpp = false;
	$ftps = false;
	$ftpwd = false;
	
?>