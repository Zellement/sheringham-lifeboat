<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Sheringham Lifeboat";
		include("site_specific/defines.php");

	?>

<title>The Lifeboat - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="The current Sheringham lifeboat is an Atlantic 85 rigid inflatable boat named 'The Oddfellows' after The Manchester Unity Independent Order of Oddfellows who donated the cost of this boat." />
	<meta name="keywords" content="sheringham lifeboat, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">The Lifeboat</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

		<div class="col48">

			<h2>Overview</h2>

			<p>The current Sheringham lifeboat is an Atlantic 85 rigid inflatable boat named 'The Oddfellows' after The Manchester Unity Independent Order of Oddfellows who donated the cost of this boat.</p>

			<p>The Atlantic 85 is one of the new generation of RNLI B-class Atlantic inshore lifeboats, first developed by the RNLI from a design originated at Atlantic College, South Wales.</p>

			<div class="content-img">
				<img src="images/imgcontent/<?php echo $page; ?>-480.jpg" alt="<?php echo $pagekw; ?>" />
			</div>

			<p>With a crew of four, and two inversion-proof 115hp petrol engines, the lifeboat is capable of speeds in excess of 35 knots, and is fitted with a manually operated righting system which, combined with her inversion proofed engines, allows her to remain operational even after capsize.</p>

			<p>At Sheringham the boat is launched from a DO-DO (drive on - drive off) trolley directly into the sea via the slipway.</p>

			<p>Equipped with the latest in electronic equipment including radar, a chart plotter and VHF radio direction finding equipment, she has an endurance of 2.5 hours.</p>

			<p>The Oddfellows has an overall length of 8.3m, a beam of 2.8m and a draught with engines raised of just 50cm</p>

		</div>

		<div class="col49">

			<h2>Hull</h2>

			<p>The hull is made from a carbon fibre and foam core laminate that minimises the internal structure whilst maintaining overall stiffness. The foam is a very tough material that has the ability to absorb and recover from high impact loads such as pounding through waves at speed. This material is stronger than wood, non-corroding, invulnerable to attack by marine organisms and easily moulded into complex shapes. The hull is shaped with a deep V forward to a flat run aft, the deep V bow gives the boat excellent directional stability when underway and the flat run assists in getting the boat up on the plane quickly and on the occassion that the boat needs to be beached she will sit upright.</p>

			<div class="content-img2">
				<img src="images/imgcontent/<?php echo $page; ?>2-480.jpg" alt="<?php echo $pagekw; ?>" />
			</div>

			<p>The bow contains ballast tanks which are filled with water to provide the boat with more stability and may be filled and emptied while at sea by the the use of a handle near the helmsman which lowers a scoop to fill the tanks while the boat is underway.</p>

			<p>Two stainless steel fuel tanks are installed in the hull, one to port the other to starboard, both are embedded in polystyrene and can be used to feed each engine independently or one tank to both engines if needed. </p>

		</div>

		<hr />

		<div class="col48">

			<h2>Sponson</h2>

			<div class="content-img3">
				<img src="images/imgcontent/<?php echo $page; ?>3-480.jpg" alt="<?php echo $pagekw; ?>" />
			</div>

			<p>The sponson is the inflatable tube (made of tough Nylon weave) which runs around the outside of the boat allowing the boat to operate in rough seas and provides fendering when going alongside other vessels.  The sponson is composed of a number of separate compartments, if one is accidentally punctured then the others will remain inflated although the boat is still capable of floating without the sponson.</p>

			<div class="content-img4">
				<img src="images/imgcontent/<?php echo $page; ?>4-480.jpg" alt="<?php echo $pagekw; ?>" />
			</div>

		</div>

		<div class="col49">

			<h2>Console</h2>

			<p>The console is fitted in the centre of the boat and provides the helsman's controls and seating for the crew, with the helmsman at the front, radio operator behind him to the port side, navigator to starboard and the fourth man's seat behind them.  All crew positions have foot straps fitted to the deck to allow the crew to 'ride the bumps'.  Although there are only four crew seats the boat is capable of carrying over twenty people if necessary.</p>

			<p>At the very front of the console is the anchor, warp and chain, when deployed the anchor warp is passed through the fairlead at the very front of the boat which will ensure that the boat is always held head on to seas, it also prevents wear on the sponson and will prevent the possibility of capsize caused by an anchor rope going over the side of a sponson. </p>

			<div class="content-img5">
				<img src="images/imgcontent/<?php echo $page; ?>5-480.jpg" alt="<?php echo $pagekw; ?>" />
			</div>

			<p>The helmsman has control of the steering wheel and single hand operation of the engine controls (throttles, gears and engine tilt/trim).  Also on the helmsmans console are the illuminated compass, depth sounder, various switches for controlling navigation lights, engine start/stop, individual tachometers and motor high temperature warning lights.</p>

			<p>Behind the helmsman on the port side is the water-tight VHF radio, hand microphone and loud speaker, (the helmsman also has a radio speaker and mike in his helmet which is controlled by a switch on the throttle handle). Directly behind the helmsman is the Global Positioning System (G.P.S.)/Radar control &amp; display screen which provides co-ordinates, estimated speed, and guidance to programmable waypoints (although waterproof charts of the local area are stored in pockets in the console in case necessary).  The 85 also has DF radio which will indicate the compass heading that a calling station is coming from - very useful when trying to find a vessel in radio contact but poor visibility. </p>

			<p>The middle crew seat on the console can be lifted to gain access to the petrol tank filler caps and a locker for gear such as a foot pump for topping up the sponson and an aerosol operated fog horn.  In another locker on the console a number of flares are stored - red for distress and white parachute flares.  The parachute flares are used when trying to locate a casualty at night. The parachute flares are fired into the air to produce a very bright light which slowly descends on a parachute illuminating a large area.</p>

			<p>To the rear of the console is the 35m towing rope on a reel which is used in conjunction with the tow bar to tow stricken vessels to safety. </p>

		</div>

		<hr />

		<div class="col48">

			<h2>Roll-bar </h2>

			<p>The roll-bar, also known as the A-Frame or Gantry, is located at the very stern of the boat and supports the self righting bag, navigation lights and aerials.  In the event of a capsize in very shallow water the roll-bar will give some protection to the crew, motors and console.  </p>

			<div class="content-img6">
				<img src="images/imgcontent/<?php echo $page; ?>6-480.jpg" alt="<?php echo $pagekw; ?>" />
			</div>

			<p>The self righting airbag is stored on top of the a-frame and may be inflated using the compressed gas cylinders located at the base of the rollbar. If the boat should capsize a handle at either side of the boat outside of the stern (ie, accessible from the water when the lifeboat is inverted) will empty the contents of one of the gas bottles into the airbag which will then cause the boat to roll the right way up. </p>

		</div>

		<div class="col49">

			<h2>Engines</h2>

			<p>The twin 115hp Yamaha engines are capable of taking the boat to a speed of 35 knots, both are petrol, water cooled and each power a propellor by a vertical drive shaft through a remotely controlled gearbox. Each gear box offers one forward, one reverse gear and a neutral position.  The engines may be operated completely independently of each other if required.  The RNLI has made some specific modifications to the engines to allow them to be immersion proof - - a mercury switch operated solenoid valve will shut off the air inlet and cut off ignition if the boat reaches an angle of heel   of 90 degrees - the exhaust system has a u-tube assembly and one way exhaust valves to prevent water entering when the engine is inverted.</p>

			<div class="content-img7">
				<img src="images/imgcontent/<?php echo $page; ?>7-480.jpg" alt="<?php echo $pagekw; ?>" />
			</div>

		</div>

		</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>