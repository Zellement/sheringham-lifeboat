<a class="donate" onclick="window.open(this.href);" href="https://rnli.org/donateorbecomeamember/Pages/One-off-Donation.aspx">
	<span class="tag">The Royal National Lifeboat Institution is funded entirely by voluntary contributions.</span>
	<span class="link">Donate to the RNLI</span>
</a>