<script type="text/javascript" src="includes/scripts/modernizr.js"></script>

<link rel="image_src" href="http://www.sheringhamlifeboat.co.uk/images/svg/fbshare.jpg" />

<!--[if (lt IE 9) & (!IEMobile)]><script type="text/javascript" src="includes/scripts/media-query-polyfill.js"></script><![endif]-->