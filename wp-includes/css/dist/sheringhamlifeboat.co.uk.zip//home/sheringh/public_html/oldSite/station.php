<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Sheringham Lifeboat Station";
		include("site_specific/defines.php");

	?>

<title>The Station - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="Sheringham lifeboat station was established in 1838 when the Hon. Mrs Charlotte Upcher provided the lifeboat 'Augusta'. In 1894 this boat was replaced by 'Henry Ramey Upcher' another lifeboat funded by the Upcher family." />
	<meta name="keywords" content="sheringham lifeboat station, station, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">The Station</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

		<p>Sheringham lifeboat station was established in 1838 when the Hon. Mrs Charlotte Upcher provided the lifeboat 'Augusta'. In 1894 this boat was replaced by 'Henry Ramey Upcher' another lifeboat funded by the Upcher family. The first RNLI boat, 'Duncan' was sent in 1867, she was launched from a carriage and was housed at the East of the town near the Crown Inn.</p>

		<div class="content-img">
			<img src="images/imgcontent/<?php echo $page; ?>-480.jpg" alt="<?php echo $pagekw; ?>" />
		</div>

		<blockquote>The current lifeboat house was constructed in 1936 at a cost of &pound;7,616 for Sheringham's first motor lifeboat - 'Foresters' Centenary'. </blockquote>

		<p>The boat on it's launching trolely &amp; the tractor take up most of the room downstairs in the boathouse, also downstairs is the RNLI giftshop and the drying room where the crew's drysuits, lifejackets and other equipment is stored. Upstairs is the radio room from where the 'shouts' are co-ordinated, a small kitchen, the Hon. Sec's office and the crew room where meetings, debriefings and talks are held.</p>

		<div class="content-img2">
			<img src="images/imgcontent/<?php echo $page; ?>2-480.jpg" alt="<?php echo $pagekw; ?>" />
		</div>

		</div>

	<div class="sidebar">

		<a title="Sheringham Lifeboat Station" rel="gallery" class="fancybox" href="images/imgcontent/station-full.jpg"><img alt="<?php echo $pagekw; ?>" src="images/imgcontent/station-thumb.jpg" /></a>

		<a title="Sheringham Lifeboat Station" rel="gallery" class="fancybox" href="images/imgcontent/station-full2.jpg"><img alt="<?php echo $pagekw; ?>" src="images/imgcontent/station-thumb2.jpg" /></a>

	</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>