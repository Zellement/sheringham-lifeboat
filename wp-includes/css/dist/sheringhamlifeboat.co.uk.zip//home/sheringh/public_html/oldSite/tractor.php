<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Tractor";
		include("site_specific/defines.php");

	?>

<title>The Tractor - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="The launching tractor used at Sheringham is a Talus MB-4H tractor unit powered by a 4.4 litre, 4 cylinder turbo charged Caterpillar 3114 diesel engine. It is a pivot steer type with all electrical, mechanical and hydraulic links passing through central wire-reinforced hose." />
	<meta name="keywords" content="sheringham lifeboat station tractor, tractor, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">The Tractor</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

			<p>The launching tractor used at Sheringham is a Talus MB-4H tractor unit powered by a 4.4 litre, 4 cylinder turbo charged Caterpillar 3114 diesel engine. It is a pivot steer type with all electrical, mechanical and hydraulic links passing through central wire-reinforced hose.  This design allows steering articulation of 40 degrees to the left or right and results in a turning circle of only ten metres. </p>

		<div class="content-img">
			<img src="images/imgcontent/<?php echo $page; ?>-480.jpg" alt="<?php echo $pagekw; ?>" />
		</div>


			<p>Control of the tractor is similar to that of a car with automatic transmission.  Forward and reverse gears are selected by a small control level, and the driver, by rotation of the driving seat, is always able to face in the direction of travel.  High or low ratio is selected by a button, although high ratio can only be used for forward travel. The tractor's speed is varied by varying the engine revs, and the talus's hydraulic control system automatically compensates for slopes or loading by providing the maximum possible speed compatible with the engine power being used.</p>

		<div class="content-img2">
			<img src="images/imgcontent/<?php echo $page; ?>2-480.jpg" alt="<?php echo $pagekw; ?>" />
		</div>

			<p>The tractor is fitted with a winch, controlled from the rearward facing direction by means of a 'deadman' pedal and joystick.  It has a radio for communication with the lifeboat and lifeboat station and can operate in broken water up to the top of the air breather pipe if necessary, as it's engine compartment is completely water tight.</p>

		<div class="content-img3">
			<img src="images/imgcontent/<?php echo $page; ?>3-480.jpg" alt="<?php echo $pagekw; ?>" />
		</div>

			<p>The launching trailer for the boat is known as a D.O.D.O. trailer (Drive on, Drive off) it has a number of features to enable the safest possible launching &amp; recovery from an open beach launch site. </p>

		<div class="content-img4">
			<img src="images/imgcontent/<?php echo $page; ?>4-480.jpg" alt="<?php echo $pagekw; ?>" />
		</div>

			<p>The trailer has a hydraulic lifting system which allows the boat to be raised when launching into rough seas and to enable the boat to launch from the slipway at hightide without the bow being angled into the water. A wing-tank on either side of the trailer supplies each outboard engine with enough water to allow the engines to be started and warmed up on the slipway before launching. </p>

			<p>Recovery into the trailer may be carried out in two ways:</p>

			<ul>

				<li><strong>Net recovery</strong> - in moderate to rough seas the boat is recovered by driving at high speed into a net rigged in the trailer. The net stops the boat once in the trailer and the crew then attach a rope (connected to either side of the stern of the boat) to the trailer using a carabiner to prevent the boat from sliding back out of the trailer. Once the boat is back up the slipway on level ground a portable turntable is slid underneath the boat and manually lifted to raise the boat off the trailer. The tractor pulls the trailer away from the boat, the boat is turned to face in the other direction, the trailer is brought back under the boat and the turntable lowered to place the boat back on the trailer in the launching position.</li>

				<li><strong>Stern-in recovery</strong> - When the sea condition is calm enough the helmsman may decide to back the boat into the trailer at a gentle pace, in this case the net is not attached to the trailer. Stern-in recovery saves having to rig the recovery net and turn the boat on the turntable after recovery, it also provides a much smoother ride for casualties.</li>

			</ul>

		</div>

	<div class="sidebar">

		<a title="Sheringham Lifeboat Station" rel="gallery" class="fancybox" href="images/imgcontent/<?php echo $page; ?>-full.jpg"><img alt="<?php echo $pagekw; ?>" src="images/imgcontent/<?php echo $page; ?>-thumb.jpg" /></a>

		<a title="Sheringham Lifeboat Station" rel="gallery" class="fancybox" href="images/imgcontent/<?php echo $page; ?>-full2.jpg"><img alt="<?php echo $pagekw; ?>" src="images/imgcontent/<?php echo $page; ?>-thumb2.jpg" /></a>

		<a title="Sheringham Lifeboat Station" rel="gallery" class="fancybox" href="images/imgcontent/<?php echo $page; ?>-full3.jpg"><img alt="<?php echo $pagekw; ?>" src="images/imgcontent/<?php echo $page; ?>-thumb3.jpg" /></a>

		<a title="Sheringham Lifeboat Station" rel="gallery" class="fancybox" href="images/imgcontent/<?php echo $page; ?>-full4.jpg"><img alt="<?php echo $pagekw; ?>" src="images/imgcontent/<?php echo $page; ?>-thumb4.jpg" /></a>

	</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>