<!--[if lte IE 7]>
<div class="ie7">

<img src="images/misc/form-error.png" alt="Warning" /> You are using an outdated browser. Please <a href="https://www.google.com/intl/en/chrome/browser/">upgrade your browser</a>

</div>
<![endif]-->

<header>

	<div class="headercontainer">

		<a href="index"><img class="logo" src="images/svg/logo.svg" alt="Sheringham Lifeboat Logo" /></a>

		<nav>

		    <ul>
		        
		    	<?php include ("includes/content/nav.php"); ?>
		        
		    </ul>

		</nav>

	    <ul class="social">

	    	<?php include ("includes/content/social.php"); ?>

	    </ul>

	</div>

</header>