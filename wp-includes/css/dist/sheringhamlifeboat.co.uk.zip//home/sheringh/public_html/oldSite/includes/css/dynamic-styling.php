<?php
header("Content-Type: text/css");
?>

#<?php echo $_GET['page'];?> .subpage-outerContainer {
	background-image: url(../../images/imgmain/<?php echo $_GET['page'];?>-768.jpg);
}

#<?php echo $_GET['page'];?> nav li .<?php echo $_GET['page'];?>-a{
	background: #eee;
} 

@media only screen and (min-width: 768px) {
	#<?php echo $_GET['page'];?> .subpage-outerContainer {
		background-image: url(../../images/imgmain/<?php echo $_GET['page'];?>.jpg);
	}
	#<?php echo $_GET['page'];?> nav li .<?php echo $_GET['page'];?>-a{
		background: #fff;
		border-color: #FF8F00;
	} 
}

@media only screen and (min-width: 480px) {
	.content-img {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>-768.jpg);
	}
	.content-img2 {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>2-768.jpg);
	}
	.content-img3 {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>3-768.jpg);
	}
	.content-img4 {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>4-768.jpg);
	}
	.content-img5 {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>5-768.jpg);
	}
	.content-img6 {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>6-768.jpg);
	}
	.content-img7 {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>7-768.jpg);
	}
	.content-img8 {
		background-image: url(../../images/imgcontent/<?php echo $_GET['page'];?>8-768.jpg);
	}
}