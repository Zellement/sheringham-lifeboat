<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Sheringham Lifeboat";
		include("site_specific/defines.php");

	?>

<title>History - Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="Sheringham's history is firmly embedded in it's relationship with the uncertain North Sea on it's doorstep, the often turbulent waters of which have claimed both land and lives over the years." />
	<meta name="keywords" content="sheringham, history, lifeboat station, rnli, saving lives at sea" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="outerContainer subpage-outerContainer">

	<div class="subpage-taglinecontainer">
		
		<h1 class="subpage-tagline">History</h1>

	</div>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="maincontent">

			<div class="col48">

				<p>Sheringham's history is firmly embedded in it's relationship with the uncertain North Sea on it's doorstep, the often turbulent waters of which have claimed both land and lives over the years.</p>

				<p>Evidence of occupation can be traced as far back as the 9th century BC and a Roman kiln has been excavated at Upper Sheringham. The first known records of Sheringham are recorded in the Doomsday Book of 1086 in which a church at Silingham is mentioned.</p> 

				<p>Much land has been lost to erosion but the high ground of the Cromer Ridge has always been a good vantage point from which to watch for unwelcome visitors and on which warning beacons could be lit. </p>

				<p>Early fishermen launched their boats from the Sheringham Hythe to the west of the town, theirs was the main industry and one that continued as the main source of income until well into the present century. In the late 1800s upwards of 200 fishing boats could have been seen working off local beaches, many arguments and disagreements were a common occurrence, not to mention the danger associated with all these boats trying to land at the same times to suit the tides. It was this situation that led some fishermen to load up their worldly belongings into their boats and travel to such places as Grimsby, Hull, Skegness and Great Yarmouth to start new lives. </p>

			</div>

			<div class="col49">

				<img class="historyImage" src="images/imgcontent/<?php echo $page; ?>01.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col48">

				<p>The population of the town in 1801 was 392 which mainly consisted of the large fishing families such as the Wests, Craskes, Coxs, Bishops, Peggs, Farrows and Grices. It was common that the fathers and sons shared the same names, there were once 14 Henry Grices living in Beeston road! To distinguish between each other they used nicknames based on either:</p>

				<ol class="alphabet">

					<li>Physical characteristics, eg. 'Squinter' West (left)</li>
					<li>Physical actions, eg. 'Bounce' Craske, (from his manner of walking)</li>
					<li>Expressions used, eg. 'Gofather' Pegg, (as he used to say to his father when he went fishing and wanted him to take him)</li>

				</ol>

				<p>It was the loss of life among local fishermen in tragedies at sea that led members of the Upcher family of Sheringham Hall to donate money to enable lifeboats to be built and their generosity founded the lifeboat service in Sheringham. Firstly came the private boats, followed by the boats supplied by the newly named Royal National Lifeboat Institution (previously known as the National Instituation for the Preservation of Life from Shipwrecks).</p>

			</div>

			<div class="col49">

				<img class="historyImage" src="images/imgcontent/<?php echo $page; ?>02.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col48">

				<p>The year of 1887 proved to be a turning point in Sheringham's history. The catalyst was the arrival of the railway in June of that year. This led to a veritable explosion of building, with new roads, pavements, a promenade, hotels, shops and houses appearing at such a pace that within just a few years Sheringham and the Sheringham Hotel catered for the cream of national society. Sheringham fishermen realised there was money to be made from this invasion of people to the town and let out deck chairs and took the visitors on fishing trips. In many instances the fishing families let out their entire cottages with the family making do with the wash-house or backroom.</p> 

				<p>The North Norfolk coast has always been regarded as a potential invasion area and this threat was underlined during the two world wars, when thousands of troops were stationed in and around the town. The anti-aircraft training camp at Weybourne brought in regular batches of hundreds of men and this, with the regiments already in residence, gave Sheringham the atmosphere of a garrison town. During World War II Sheringham was very much a 'front line' town, under threat from a possible invasion, with frequent air-raids which made it a dangerous place to live. On January 14th 1915 the first bomb to hit British soil was dropped by Zeppelin L4 and fell through the roof of a house in Whitehall Yard, Sheringham, without exploding (parts of this bomb can be seen in the Sheringham Museum). In addition to the normal hazards of the job the fishermen now had to be alert for floating mines in the water. </p>

			</div>

			<div class="col49">

				<img class="historyImage" src="images/imgcontent/<?php echo $page; ?>03.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col48">

				<p>In the immediate post-war years there were quite radical plans to demolish most of the northern end of the High street from the Clock tower to the seafront and re-develop it along the lines of a miniature Great Yarmouth or Skegness. Fortunately the necessary capital could not be raised and the character of the town was preserved. </p>

				<p>The last thirty years or so have seen a great deal of housing expansion as new estates have been built to the south of the town, in terms of new households Sheringham has seen the biggest growth of any town in North Norfolk. The history, geology and archaeology of Sheringham has been preserved as much as possible in the Sheringham Museum in station road, with a number of the old lifeboats soon to be displayed in the new lifeboat museum on the seafront next to the Crown Inn.</p>

			</div>

			<div class="col49">

				<img class="historyImage" src="images/imgcontent/<?php echo $page; ?>04.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<hr />

			<div class="col20">

				<h3>Augusta</h3>

				<h4 class="year">1838 - 1894</h4>

				<h5>Private Lifeboat</h5>

			</div>

			<div class="col25">

				<img src="images/history/augusta.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

				<p>The Augusta was a private lifeboat built by Robert Sunman in the style of the local crab boats at a cost of £134.12s.2d. Mrs. Charlotte Upcher of Sheringham Hall provided the fishing community with a lifeboat after some severe gales along the East coast in 1836 caused a number of deaths amongst the Sheringham fishermen.</p> 

				<p>The Augusta was named after Mrs. Upcher's youngest child and launched on November 1838. The lifeboat measured 33'6" long x 10'3" wide, was fitted with 16 oars, a dipping lug mainsail, mizzen sail and had fittings for a rudder at either end to avoid turning her in heavy seas.</p> 

				<p>Her services were not recorded at the time although tradition credits her with 200 launches and 1000 lives saved, research so far has established just over 200 lives saved in 16 launches with 4 further unconfirmed services.</p>

			</div>

			<hr />

			<div class="col20">

				<h3>Duncan</h3>

				<h4 class="year">1867 - 1886</h4>

			</div>

			<div class="col25">

				<img src="images/history/duncan.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

				<p>The Duncan was the first RNLI lifeboat at Sheringham and arrived on 31st July 1867. </p>

				<p>She was 36' long x 9'4" wide, self righting by virtue of her heavy iron keel and high end boxes and was supplied with 12 oars and a single mast with sail. She was built by Forrestt of Limehouse for £345, the cost being met by a donation from Mrs. Agnes Fraser (nee Duncan) in memory of her father and uncle. </p>

				<p>The Duncan remained at Sheringham for 19 years, made 7 effective service launches and saved 18 lives. </p>

			</div>

			<hr />

			<div class="col20">

				<h3>William Bennett</h3>

				<h4 class="year">1886 - 1904</h4>

			</div>

			<div class="col25">

				<img src="images/history/william-bennett.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

				<p>The William Bennett arrived at Sheringham on 7th July 1886 by sea. She was 41'4" long x 9'3" wide, had 14 oars and was a self righting design.</p>

				<p>She was built by Forrestt of Limehouse and cost £500 13s 10d, paid by a legacy from Mr W. Bennett of Regent's Park, London. The William Bennett was just over 5 feet longer and considerably heavier than the Duncan, and this combined with the narrow access to the slipway, made the William Bennett a very difficult boat to launch. Consequently, during the 18 years she was stationed at Sheringham, she only made 4 successful service launches, saving 11 lives.</p>

			</div>

			<hr />

			<div class="col20">

				<h3>Henry Ramey Upcher</h3>

				<h4 class="year">1894 - 1935</h4>

				<h5>Private Lifeboat</h5>

			</div>

			<div class="col25">

				<img src="images/history/henry-ramey-upcher.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

				<p>The Henry Ramey upcher was the gift of Mrs. Caroline Upcher of Sheringham Hall, donated to the fishermen in memory of Mrs. Upcher's husband. 
				She was built by Lewis 'Buffalo' Emery of Sheringham, for £150, in the style of the local crab fishing boats; using local oak for the planking and fastened throughout with copper. She measured 39'9" long x 11'3" wide, was double ended, carried 16 oars and was fitted with a large dipping lug-mainsail and a mizzen. She was named by Mrs. Upcher on 4th Sept 1894 and remained in service until 1935. She worked closely with the RNLI station boats William Bennett and J.C. Madge, and was very popular with the fishermen as she was lighter than the RNLI boats and could be launched faster, (although her width tended to make her more liable to ship water in severe conditions so was less suitable than the RNLI boats in heavy seas).</p> 

				<p>The Henry Ramey Upcher launched over 50 times and saved over 200 lives. A full crew was generally 28 men: coxwain, deputy coxwain, 16 oarsmen, 8 men to tend the sails and 2 more men to work the pumps near the stern. </p>

				<p>One of the most famous of The Henry Ramey Upcher's rescues was to the Ispolen on 23rd Jan 1897. A strong North Easterly gale with snow had been blowing for 48 hours along the North Sea coasts raising heavy seas. The 236 ton wooden brig was enroute from Norway to Gravesend laden with ice. Two days after setting off on the 19th January she encountered very rough weather, shipping so much water that her pumps had to be kept going. By the 23rd she had sprung a leak and, with the wind dead on shore, was unable to prevent herself being driven towards the coast. </p>

				<p>The RNLI lifeboat William Bennett could not be launched directly, as the slipway had been washed away the day before, the Henry Ramey Upcher managed to get afloat first and was on the scene as soon as the Ispolen stuck at 1.30pm. The crew of the Ispolen were all Norwegian so did not understand the lifeboat's crew when they shouted for ropes, so a second approach had to be made, this time with only 14 oars as two had broken on the first approach. The lifeboat men succeeded in throwing grappling hooks into the Ispolen's rigging and hauled alongside. </p>

				<p>The eight crew of the brig jumped on board the Henry Ramey Upcher and were safely landed at Sheringham. The rescued men were taken to the Two Lifeboats inn (then a coffee house) and given dry clothes. By evening the Ispolen had broken up and her cargo of ice scattered along the shore. 
				The keel and some timbers from the wreck can still be seen on Sheringham Beach a little to the west of the Henry Ramey Upcher boathouse when a rough spell has washed away some of the sand.</p> 

			</div>

			<hr />

			<div class="col20">

				<h3>J.C. Madge</h3>

				<h4 class="year">1904 - 1936</h4>

			</div>

			<div class="col25">

				<img src="images/history/jc-madge.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

			<p>The J.C. Madge was a 41' long x 11' wide, non-self righting, pulling and sailing Liverpool class boat, the largest of the type ever built. 
			She was rowed by 16 oars, had two drop keels, two water ballast tanks and two masts. She was built by the Thames Ironworks Shipbuilding Co., Blackwall, at a cost of £1,436, provided by a legacy from Mr. James C. Madge of Southhampton. She arrived on station on the 2nd December 1904 having sailed around the coast from Blackwall. </p>

			<p>The J.C. Madge was launched on service 34 times and saved 58 lives. The boat was carriage launched requiring a team of 30 or more men to haul her into the waves, then if possible she was rowed out through the surf. If rowing out was not possible she was hauled out using the the haul-off warp - a thick rope anchored some 200 metres off shore and fixed at the beach end by the lifeboat house (located at the Old Hythe, at the West end of Sheringham golf course).</p>

			<p>On 24th Feb 1916 the J.C. Madge went to the assistance of the SS Uller of Bergen. The Uller, bound from Sunderland to La Pallice with a cargo of coal, struck a sandbank early in the morning of the 24th February. </p>

			<p>Seriously damaged she floated off, and drifted for some eighteen hours, until she again struck the bottom on the Blakeney Overfalls bank. In great difficulty she drifted clear into deeper water and made signals for assistance. The day had been wild and stormy and the snow was falling thickly as the maroons called out the Sheringham Lifeboat. </p>

			<p>Messages were received that both Cromer and Wells lifeboats were unable to launch due to the severity of the storm. The Sheringham crew had a long run, in the dark, from the town to the lifeboat house over the cliffs which had been trenched and barb-wired. </p>

			<p>	Eventually the J.C. Madge was launched by means of the haul-off warp, the first wave she met buried the boat and soaked the crew to the skin. The Uller was discovered just inside the Blakeney Overfalls at around 10pm that evening and the second coxwain and a crewmember went on board to discuss the situation with her captain. The Uller still had steam and could achieve half power so, for the rest of the night, through swirling snow, the Sheringham men stood by in their open boat. </p>

			<p>In the morning the Uller began the voyage towards Grimsby, the lifeboat being towed behind on a 90ft tow line, her crew having to make constant effort not to be flung onto the Uller's propellor, now half out of the sea due to the water in her damaged bow.</p>

			<p>It took two days for the vessels to reach the Humber, the lifeboatmen spent the night in Grimsby where many had family and friends. The crew's family and friends however had received no news of the lifeboat which had disappeared into the darkness 24 hours before. A passing French steamer took the lifeboat in tow for some of the long journey home and the J.C. Madge finally returned to station at 6pm on the 28th February.</p>

			</div>

			<hr />

			<div class="col20">

				<h3>Foresters' Centenary</h3>

				<h4 class="year">1936 - 1961</h4>

			</div>

			<div class="col25">

				<img src="images/history/foresters-centenary.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

			<p>The Foresters' Centenary was a 35'6" long x 10'3" wide, single screw, non self-righting, Liverpool class motor lifeboat built in 1936 at Groves &amp; Guttridge, Isle of Wight at a cost of £3,569.</p>

			<p>She was fitted with one 35hp petrol engine which gave a top speed of 7.3 knots. She was also supplied with jib, main and mizzen sails in case of engine failure. She was the fifth boat donated to the RNLI by the Ancient Order of Foresters' Friendly Society and while at Sheringham she launched on service 129 times, saving 82 lives. Foresters' Centenary arrived on station in June 1936 and housed at the Old Hythe lifeboat house although a new boathouse was constructed nearer to the town (the current boathouse) and she was moved there on 26th February 1937.</p>

			<p>Coxwain Dumble was awarded the RNLI's Bronze Medal for the rescue of 15 men from the SS Eaglescliffe Hall on 29th/30th October 1941. Foresters' Centenary and her crew were also responsible for rescuing more airmen from the sea during World War II than any other RNLI lifeboat.</p>

			</div>

			<hr />

			<div class="col20">

				<h3>The Manchester Unity of Oddfellows</h3>
				<h3 class="sub">Oakley Class</h3>

				<h4 class="year">1961 - 1986</h4>
				<h4 class="year">1987 - 1990</h4>

			</div>

			<div class="col25">

				<img src="images/history/muoo.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

				<p>The Manchester Unity of Oddfellows, Sheringham's longest serving offshore motor lifeboat, was a 37' long x 11'6" wide, twin screw, Oakley class self-righting lifeboat. A gift of the Manchester Unity Friendly Society (The Oddfellows), she was built at William Osborne's shipyard, Littlehampton and cost £28,500. </p>

				<p>During her 29 years on station at Sheringham, the Manchester Unity of Oddfellows launched on service 127 times and saved 134 lives.</p>

				<p>Her coxwains were as follows:</p> 

				<ul>

					<li>1961 - 1962 Henry 'Downtide' West</li>
					<li>1963 - 1984 Henry 'Joyful' West B.E.M.</li>
					<li>1985 - 1986 Jack West</li>
					<li>1986 - 1990 Brian Pegg</li>

				</ul>

				<p>Clive Rayment oversaw the change-over from the Manchester Unity of Oddfellows to the last offshore boat Lloyds II in 1990. </p>

				<p>The Manchester Unity of Oddfellows arrived at Sheringham on 10th July 1961, she was fitted with twin Perkins P4M, 43 hp diesel engines giving a maximum speed of 8 knots. She had a quick release mechanism for launching from the carriage and in the event of capsize the lifeboat would automatically self-right. Her self-righting mechanism relied upon the transfer of one and a half tons of sea water which, on launching, entered and was stored in the ballast tank beneath the engine in the centre of the craft. If a capsize occurred this tank would be at the highest part of the boat and the water in it would fall through ducts into a second (righting) tank on the port side just below the deck. The extra weight on the port side would start the boat rolling, bringing her upright in 7 seconds. </p>

				<p>One particularly tricky rescue carried out by The Manchester Unity of Oddfellows was to four people on a converted ship's lifeboat Lucy. The Lucy was on her maiden voyage from Peterborough to Southwold on 15th August 1961, the weather was cold with a strong NW wind and short steep sea. Towards noon the Lucy sprung a leak at the stern and started to take on water rapidly. Distress signals were spotted and Sheringham Lifeboat launched using the haul-off rope to prevent her being washed broadsides onto the beach. Just as the boat left the carriage the mast holding the haul-off rope snapped and it was only by skilful handing by coxwain Henry 'Downtide' West that tradgedy was averted.</p>

				<p>The Manchester Unity of Oddfellows found the Lucy 5 miles N.E. of Sheringham and three crewmen boarded the craft and helped transfer the owner's unconcious wife and young son to the lifeboat. The owner was transferred next, while the forth member of the crew remained on board with the lifeboatmen while a tow was attempted. In the fierce swell the rope snapped and the coxwain decided to evacuate the four men remaining on board. The casualties were landed at Sheringham and all made a full recovery. </p>

				<p>Coxwain Henry 'Downtide' West, and the three crewmen that boarded the boat (Henry 'Joyful' West, Arthur Scotter and Eric Wink) received Vellums from the RNLI.</p> 

				<p>When The Manchester Unity of Oddfellows was retired from service her place was taken by the last of Sheringham's all-weather lifeboats, the Lloyds II, built in 1966 and paid for by donations from members of Lloyds of London. On 18th April 1992, Lloyds II left Sheringham having performed seven services while on station.</p>

			</div>

			<hr />

			<div class="col20">

				<h3>The Manchester Unity of Oddfellows</h3>
				<h3 class="sub">Atlantic 75</h3>

				<h4 class="year">1994 - Present</h4>

			</div>

			<div class="col25">

				<img src="images/history/muoo2.jpg" alt="<?php echo $pagekw; ?>" />

			</div>

			<div class="col55">

				<p><a href="lifeboat">Click here to find out about the Atlantic 75.</a>

			</div>

			<hr />

		</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>