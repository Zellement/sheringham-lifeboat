<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script type="text/javascript" src="includes/scripts/selectivizr-min.js"></script>
<script type="text/javascript" src="includes/scripts/svgeezy.js"></script>

<script type="text/javascript" src="fancybox/jquery.fancybox.pack.js"></script>

<script type="text/javascript" src="includes/scripts/jquery.cookie.js"></script>
<script type="text/javascript" src="includes/scripts/jquery.cookiecuttr.js"></script>

<script type="text/javascript">
if (jQuery.cookie('cc_cookie_accept') == "cc_cookie_accept") {}
$(document).ready(function () {
$.cookieCuttr();
//setting automatic cookies:
setTimeout(function () {
   jQuery('.cc-cookie-accept').trigger('click');
}, 50000);
}); 
</script>

<script type="text/javascript" src="includes/scripts/run.js"></script>

<?php include("includes/scripts/canonical-link.php"); ?>