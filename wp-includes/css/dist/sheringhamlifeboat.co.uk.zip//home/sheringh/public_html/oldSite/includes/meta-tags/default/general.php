<meta http-equiv="content-language" content="EN" />

<meta name="page-author" content="Zellement Design (www.zellement.com)" />

<meta name="copyright" content="Copyright (C) <?php echo $companyName; ?>" />

<meta name="country" content="UK" />

<meta name="distribution" content="Global" />

<meta name="revisit-after" content="15 days" />

<meta name="document-rating" content="Safe For Kids" />

<meta name="robots" content="index, follow" />                             