<div class="un1fyDashSidebar">
                <h3>Unify Twitter Feed</h3>
                <div id="twitter_div">
                    <ul id="twitter_update_list"></ul>
                    <p class="follow"><a href="http://twitter.com/unifysupport" id="twitter-link" style="display:block;text-align:right;">follow Unify updates on Twitter</a></p>
                </div>
            </div>
        </div>
        <div class="un1fyDashFooter">
            <p><strong>Thanks for using Unify&trade;</strong> <span><?php echo $ver; ?></span> <a href="http://unify.unitinteractive.com">Visit the Unify Website</a></p>
            <p>&copy; <?php echo date('Y'); ?> Unit Interactive, LLC</p>
        </div>
    </div><!--end of un1fyDashboardWrap-->
</div><!-- end of un1fyDashScrollWrap -->

</body>
</html>