<a class="events" href="events.php">
	<span class="headline">Events</span>
	<span class="tag">Find out all about our upcoming events.</span>
	<span class="link">Click here &raquo;</span>
</a>