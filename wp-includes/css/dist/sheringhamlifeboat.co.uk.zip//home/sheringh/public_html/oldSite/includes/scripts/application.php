<?php ob_start(); ?>

<?php function pagevar(){return str_replace('.php','', basename($_SERVER['SCRIPT_FILENAME'])); } ?>